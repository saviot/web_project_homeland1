Nama Proyek: Tugas Savio Sprint 4
Deskripsi proyek dan fungsinya: Proyek Sprint 4 yang berfungsi untuk membuat website, memberi informasi dan banyak hal
Deskripsi teknologi dan teknik yang digunakan: Teknologi yang digunakan yaitu figma vs code dan menggunakan teknik html css
